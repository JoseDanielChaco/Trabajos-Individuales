<?php
include 'conexion.php';

$nombre = $_POST['nombre'];
$ingredientes = $_POST['ingredientes'];
$preparacion = $_POST['preparacion'];
$imagen = $_POST['imagen'];

$sql = "INSERT INTO recetas (nombre, ingredientes, preparacion, imagen) VALUES (?, ?, ?, ?)";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ssss", $nombre, $ingredientes, $preparacion, $imagen);
$stmt->execute();
$stmt->close();

header("Location: recetas.php");
?>
