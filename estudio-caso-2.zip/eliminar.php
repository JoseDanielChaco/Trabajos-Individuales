<?php
include 'conexion.php';
$id = $_POST['id'];
$conexion->query("DELETE FROM recetas WHERE id=$id");
header("Location: recetas.php");
?>
