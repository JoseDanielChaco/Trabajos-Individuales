
CREATE DATABASE IF NOT EXISTS recetas_db;
USE recetas_db;

CREATE TABLE IF NOT EXISTS recetas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    ingredientes TEXT,
    preparacion TEXT,
    imagen VARCHAR(255)
);
