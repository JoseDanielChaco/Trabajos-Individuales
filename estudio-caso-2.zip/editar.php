<?php
include 'conexion.php';
$id = $_POST['id'];
$prep = $_POST['preparacion'];
$conexion->query("UPDATE recetas SET preparacion='$prep' WHERE id=$id");
header("Location: recetas.php");
?>
