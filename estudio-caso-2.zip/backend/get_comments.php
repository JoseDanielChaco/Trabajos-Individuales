<?php
include 'db.php';
$task_id = $_GET['task_id'];
$stmt = $pdo->prepare("SELECT * FROM comentarios WHERE task_id = ? ORDER BY id DESC");
$stmt->execute([$task_id]);
echo json_encode($stmt->fetchAll());
?>