<?php
include 'db.php';
$id = $_GET['id'];
$stmt = $pdo->prepare("DELETE FROM comentarios WHERE id = ?");
$stmt->execute([$id]);
echo json_encode(["success" => true]);
?>