<?php
include 'db.php';
$data = json_decode(file_get_contents("php://input"));
$stmt = $pdo->prepare("INSERT INTO comentarios (task_id, comentario) VALUES (?, ?)");
$stmt->execute([$data->task_id, $data->comentario]);
echo json_encode(["success" => true]);
?>