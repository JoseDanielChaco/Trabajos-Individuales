# Estudio de Caso 2 - SC502

Este proyecto implementa comentarios para una app de gestión de tareas.

## Funcionalidades
- Ver comentarios por tarea
- Agregar comentarios dinámicamente
- Eliminar comentarios dinámicamente

## Instrucciones
1. Crear una base de datos `tareas_db` con la tabla:
```sql
CREATE TABLE comentarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  task_id INT NOT NULL,
  comentario TEXT NOT NULL
);
```
2. Asegúrese de tener configurado PHP y MySQL.
3. Coloque los archivos backend y frontend en el servidor local.
4. Acceda desde el navegador a `frontend/index.html`.

## Autor
Tu Nombre
